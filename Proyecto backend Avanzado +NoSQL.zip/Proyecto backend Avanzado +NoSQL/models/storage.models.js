import mongoose from "mongoose"

const storageSchema = new mongoose.Schema({
   id_storage: String,
   fecha_esterilización: String,
   id_esterilizacion: String,
   No_reusos: String, 
   id_device: { type: mongoose.Schema.Types.ObjectId, ref: 'Device'}
}, { strict: true })

const storage = mongoose.model("Storage", storageSchema)

export default storage