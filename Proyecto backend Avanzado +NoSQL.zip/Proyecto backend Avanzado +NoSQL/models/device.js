import mongoose from "mongoose"

const deviceSchema = new mongoose.Schema({
    id_device: String,
    nombre: String,
    No_serie: String,
    id_esterilizacion: String,
    No_reusos: String,   
  }, { strict: true })

const Device = mongoose.model("Device", deviceSchema)

export default Device