import mongoose from "mongoose"

const washingSchema = new mongoose.Schema({
    id_washing: String,
    fecha_washing: String,
    tipo_respi_instrumen: String,
    id_device: { type: mongoose.Schema.Types.ObjectId, ref: 'Device'}
}, { strict: true })

const washing = mongoose.model("Washing", washingSchema)

export default washing