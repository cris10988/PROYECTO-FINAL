import mongoose from "mongoose"

const packagingSchema = new mongoose.Schema({
    nombre: String,
    No_serie: String,
    identificacion_esterilizacion: String,
    No_reusos: String, 
   id_device: { type: mongoose.Schema.Types.ObjectId, ref: 'Device'}
}, { strict: true })

const packaging = mongoose.model("Packaging", packagingSchema)

export default packaging