import mongoose from "mongoose"

const esterilizacionSchema = new mongoose.Schema({
    id_esterilizacion: String,
    met_esterilización: String,
    fecha_esterilización: String, 
    hora_esterilización: String,
   id_device: { type: mongoose.Schema.Types.ObjectId, ref: 'Device'}
}, { strict: true })

const esterilizacion = mongoose.model("Esterilización", esterilizacionSchema)

export default esterilizacion