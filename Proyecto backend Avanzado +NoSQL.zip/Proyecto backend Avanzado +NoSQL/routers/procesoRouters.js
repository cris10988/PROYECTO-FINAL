import { Router } from "express";
import Comment from "../models/device.js";
import { createdevice, getdevices, getdevice, updatedevice, deletedevice } from "../controllers/device.controllers.js"
const commentRouter = Router();

//commentRouter.use(simpleMiddleWare) <-- uso general
commentRouter.get("/", getdevice) // uso indiviudal
commentRouter.get("/:id", getdevice)
commentRouter.post("/", createdevice)
commentRouter.patch("/:id", updatedevice)
commentRouter.delete("/:id", deletedevice)
export default commentRouter