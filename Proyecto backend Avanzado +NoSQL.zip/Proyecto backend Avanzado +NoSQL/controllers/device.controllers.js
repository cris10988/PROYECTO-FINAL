import device from "./models/device.js"
import washing from "./models/washing.models.js"
import packaging from "./models/packaging.models.js"
import sterilization from "./models/sterilization.models.js"
import storage from "./models/storage.models.js"

const createdevice = async (request, response, next) => {
    try{
        const { id_device, nombre, No_serie, met_esterilizacion, No_reusos_permitidos } = request.body

        const device = await device.create({
            id_device,
            nombre,
            No_serie,
            met_esterilizacion,
            No_reusos_permitidos,           
        });

        response.json(Storage, packaging, sterilization, Storage, washing)

    } catch (error){
        next(error)
    } 
}

const getdevices = async (request, response, next) => {
    try {
      console.log("Aqui estoy entrando al controlador");
      const devices = await devices.find({}, "title content auth")
        .populate("id_devices")
        // .populate({path:"id_device"})
        .exec();
      response.status(200).json(devices);
    } catch (error) {
      next(error);
    }
  };
  
  const getdevice = async (request, response, next) => {
    try {
      const id = request.params.id;
      const device = await device.findById(id).exec();
      response.status(200).json(device);
    } catch (error) {
      next(error);
    }
  };
  
  const updatedevice = async (request, response, next) => {
    try {
      const id = request.params.id;
      const { id_device, nombre, met_esterilizacion, No_serie, No_reusos } = request.body;
  
      const nuevoBody = {
        id_device: id_device,
        nombre: nombre,
        met_esterilizacion: met_esterilizacion,
        No_serie:No_serie,
        No_reusos: No_reusos,
      };
  
      const device = await device.findByIdAndUpdate(id, nuevoBody, {
        new: true,
      }).exec();
  
      response.status(200).json(device);
    } catch (error) {
      next(error);
    }
  };
  
  const deletedevice = async (request, response, next) => {
    try {
      const id = request.params.id;
      await device.findByIdAndRemove(id).exec();
      response.status(200).end();
    } catch (error) {
      next(error);
    }
  };
 
  const createpackaging = async (request, response, next) => {
    try{
        const { id_device, nombre, No_serie, met_esterilizacion, No_reusos } = request.body

        const packaging = await packaging.create({
            id_packagig,
            nombre,
            No_serie,
            met_esterilizacion,
            No_reusos,           
        });

        response.json(Storage, packaging, sterilization, Storage, washing)

    } catch (error){
        next(error)
    } 
}

const getpackagins = async (request, response, next) => {
    try {
      console.log("Aqui estoy entrando al controlador");
      const packagings = await packagings.find({}, "title content auth")
        .populate("id_packaging")
        // .populate({path:"id_packaging"})
        .exec();
      response.status(200).json(packagings);
    } catch (error) {
      next(error);
    }
  };
  
  const getpackagin = async (request, response, next) => {
    try {
      const id = request.params.id;
      const packaging = await packaging.findById(id).exec();
      response.status(200).json(packaging);
    } catch (error) {
      next(error);
    }
  };
  
  const updatepackaging = async (request, response, next) => {
    try {
      const id = request.params.id;
      const { id_pakaging, nombre, met_esterilizacion, No_serie, No_reusos } = request.body;
  
      const nuevoBody = {
        id_pakaging: id_packagig,
        nombre: nombre,
        met_esterilizacion: met_esterilizacion,
        No_serie:No_serie,
        No_reusos: No_reusos,
      };
  
      const packaging = await packaging.findByIdAndUpdate(id, nuevoBody, {
        new: true,
      }).exec();
  
      response.status(200).json(packaging);
    } catch (error) {
      next(error);
    }
  };
  
  const deletepackaging = async (request, response, next) => {
    try {
      const id = request.params.id;
      await packaging.findByIdAndRemove(id).exec();
      response.status(200).end();
    } catch (error) {
      next(error);
    }
  };
  

  const createsterilization = async (request, response, next) => {
    try{
        const { nombre, No_serie, met_esterilizacion, No_reusos } = request.body

        const sterilization = await sterilization.create({
            nombre,
            No_serie,
            met_esterilizacion,
            No_reusos,           
        });

        response.json(Storage, packaging, sterilization, Storage, washing)

    } catch (error){
        next(error)
    } 
}

const getsterilizations = async (request, response, next) => {
    try {
      console.log("Aqui estoy entrando al controlador");
      const sterilizations = await sterilizations.find({}, "title content auth")
        .populate("id_sterilization")
        // .populate({path:"id_sterilization"})
        .exec();
      response.status(200).json(sterilizations);
    } catch (error) {
      next(error);
    }
  };
  
  const getsterilization = async (request, response, next) => {
    try {
      const id = request.params.id;
      const sterilization = await sterilization.findById(id).exec();
      response.status(200).json(sterilization);
    } catch (error) {
      next(error);
    }
  };
  
  const updatesterilization = async (request, response, next) => {
    try {
      const id = request.params.id;
      const { id_sterilization, nombre, met_esterilizacion, No_serie, No_reusos } = request.body;
  
      const nuevoBody = {
        id_sterilization: id_sterilization,
        nombre: nombre,
        met_esterilizacion: met_esterilizacion,
        No_serie:No_serie,
        No_reusos: No_reusos,
      };
  
      const sterilization= await sterilization.findByIdAndUpdate(id, nuevoBody, {
        new: true,
      }).exec();
  
      response.status(200).json(sterilization);
    } catch (error) {
      next(error);
    }
  };
  
  const deletesterilization = async (request, response, next) => {
    try {
      const id = request.params.id;
      await sterilization.findByIdAndRemove(id).exec();
      response.status(200).end();
    } catch (error) {
      next(error);
    }
  };
    

  const createstorage = async (request, response, next) => {
    try{
        const { id_storage, nombre, No_serie, met_esterilizacion, No_reusos } = request.body

        const storage = await storage.create({
            id_storage,
            nombre,
            No_serie,
            met_esterilizacion,
            No_reusos,           
        });

        response.json(Storage, packaging, sterilization, Storage, washing)

    } catch (error){
        next(error)
    } 
}

const getstorages = async (request, response, next) => {
    try {
      console.log("Aqui estoy entrando al controlador");
      const storages = await storages.find({}, "title content auth")
        .populate("id_storage")
        // .populate({path:"id_storage"})
        .exec();
      response.status(200).json(storages);
    } catch (error) {
      next(error);
    }
  };
  
  const getstorage = async (request, response, next) => {
    try {
      const id = request.params.id;
      const storage = await storage.findById(id).exec();
      response.status(200).json(storage);
    } catch (error) {
      next(error);
    }
  };
  
  const updatestorage = async (request, response, next) => {
    try {
      const id = request.params.id;
      const { id_storage, nombre, met_esterilizacion, No_serie, No_reusos } = request.body;
  
      const nuevoBody = {
        id_storage: id_storage,
        nombre: nombre,
        met_esterilizacion: met_esterilizacion,
        No_serie:No_serie,
        No_reusos: No_reusos,
      };
  
      const storage = await storage.findByIdAndUpdate(id, nuevoBody, {
        new: true,
      }).exec();
  
      response.status(200).json(storage);
    } catch (error) {
      next(error);
    }
  };
  
  const deletestorage = async (request, response, next) => {
    try {
      const id = request.params.id;
      await storage.findByIdAndRemove(id).exec();
      response.status(200).end();
    } catch (error) {
      next(error);
    }
  };
    

  const createwashing = async (request, response, next) => {
    try{
        const { id_washing, nombre, No_serie, met_esterilizacion, No_reusos } = request.body

        const Washing = await washing.create({
            id_washing,
            nombre,
            No_serie,
            met_esterilizacion,
            No_reusos,           
        });

        response.json(Storage, packaging, sterilization, Storage, washing)

    } catch (error){
        next(error)
    } 
}

const getwashings = async (request, response, next) => {
    try {
      console.log("Aqui estoy entrando al controlador");
      const washings = await washings.find({}, "title content auth")
        .populate("id_washings")
        // .populate({path:"id_washing"})
        .exec();
      response.status(200).json(washings);
    } catch (error) {
      next(error);
    }
  };
  
  const getwashing = async (request, response, next) => {
    try {
      const id = request.params.id;
      const washing = await washing.findById(id).exec();
      response.status(200).json(washing);
    } catch (error) {
      next(error);
    }
  };
  
  const updatewashing = async (request, response, next) => {
    try {
      const id = request.params.id;
      const { id_washing, nombre, met_esterilizacion, No_serie, No_reusos } = request.body;
  
      const nuevoBody = {
        id_washing: id_washing,
        nombre: nombre,
        met_esterilizacion: met_esterilizacion,
        No_serie:No_serie,
        No_reusos: No_reusos,
      };
  
      const washing = await washing.findByIdAndUpdate(id, nuevoBody, {
        new: true,
      }).exec();
  
      response.status(200).json(washing);
    } catch (error) {
      next(error);
    }
  };
  
  const deletewashing = async (request, response, next) => {
    try {
      const id = request.params.id;
      await washing.findByIdAndRemove(id).exec();
      response.status(200).end();
    } catch (error) {
      next(error);
    }
  };
  export { createwashing, deletewashing, getwashing, getwashings, updatewashing,  createdevice, deletedevice, getdevice, getdevices, updatedevice, createstorage, deletestorage, getstorage, getstorages, updatestorage, createsterilization, deletesterilization, getsterilization, getsterilizations, updatesterilization, createpackaging, deletepackaging, getpackagin, getpackagins, updatepackaging };